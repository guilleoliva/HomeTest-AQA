# -*- coding: utf-8 -*-
"""
Predefined Python behave steps to perform core web pages actions

Functions:
    - capture_images
    - open_url
    - move_back_to_previous_page
    - move_forward_to_previous_page
    - refresh_page
    - set_variable_context
    - print_text
    - click_on_element
    - set_element_text
    - send_keys_to_elements
    - select_path
    - deselect_path
    - submit_element
    - find_element_by_perfoming_close
    - double_click_element
    - mouse_over_on_element
    - drag_to_and_drop_element
    - click_and_holder_element
    - release_element
    - save_screenshot
    - switch_to_frame
    - switch_to_frame_by_index
    - switch_to_windows
    - switch_to_default_content
    - insert_text_into_alert
    - send_keys
"""
# pylint: disable=W0401 , W0614, W0622
import logging
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from ..utils.web_utils import WebUtils, click_on_element
from behave import *

@step(u'I set browser size to {size}')
def set_browser_window_size(context, size):
    """Set browser to the specified screen resolution"""
    split_size = size.split('x')
    for browser in context.browsers.values():
        browser.driver.set_window_size(split_size[0], split_size[1])
        logging.info("Browser size has been changed to {0}x{1}"
                .format(split_size[0], split_size[1]))

@step(u'I wait for "{seconds}" seconds')
def wait_for(context, seconds):
    """Wait for N seconds"""
    time.sleep(int(seconds))

@step(u'I should see "{text}" displayed within {timeout} seconds')
def should_see(context, text, timeout):
    """Search for the specified text in current page"""
    assert context.browser.is_text_present(text, wait_time=int(timeout)), u'Text not found'

@step(u'I take a screenshot for each step')
def capture_images(context):
    """Capture images"""
    context.capture_screens_after_step = True


@step(u'I open url "{url}"')
def open_url(context, url):
    """Open url in driver"""
    context.execute_steps(u'When I take a screenshot for each step')
    context.capture_screens_after_step = True
    web_utils = WebUtils(driver=context.browser.driver)
    context.web_utils = web_utils
    context.browser.driver.get(url)


@step(u'I move back to previous page')
def move_back_to_previous_page(context):
    """Move back to previous page in driver"""
    context.web_utils.driver.back()


@step(u'I move forward to next page')
def move_forward_to_previous_page(context):
    """Move forward to previous page"""
    context.web_utils.driver.forward()


@step(u'I refresh current page')
def refresh_page(context):
    """Refresh the current page"""
    context.web_utils.driver.reload()


@step(u'I set variable "{variable}" with value "{text}"')
def set_variable_context(context, variable, text):
    """Set a variable in BehaveX context """
    setattr(context, variable, text)


@step(u'I print "{text}"')
def print_text(text):
    """Print text using the default logging mechanism (logging level: INFO)"""
    logging.info(text)


@step(u'I click on element with {locator_by} "{locator}"')
def click_on_element_(context, locator_by, locator):
    """Click on the element identified by the provided locator"""
    web_utils = context.web_utils
    elem = web_utils.find_element(locator_by, locator, wait=2, retries=30)
    click_on_element(elem)


@step(u'I insert text "{text}" in element with {locator_by} "{locator}"')
def set_element_text(context, text, locator_by, locator):
    """Insert text in the element identified by the provided locator"""
    web_utils = context.web_utils
    elem = web_utils.find_element(locator_by, locator, wait=2, retries=30)
    click_on_element(elem)
    elem.clear()
    elem.send_keys(text)


@step(u'I send key "{key}" in element with {locator_by} "{locator}"')
@step(u'I add text "{text}" in element with {locator_by} "{locator}"')
def send_keys_to_elements(context, locator_by, locator, text='', key=None):
    """Send keys to an element identified by the provided locator"""
    if key:
        try:
            text = getattr(Keys, key)
        except AttributeError:
            print('Bad key in:\n\tI send key "{}" in element with {} "{}"'.
                format(key, locator_by, locator))
    web_utils = context.web_utils
    elem = web_utils.find_element(locator_by, locator, wait=2, retries=30)
    click_on_element(elem)
    elem.send_keys(text)


@step(u'I select {value} in element with {locator_by} "{locator}"')
@step(u'I select element with {locator_by} "{locator}"')
def select_path(context, locator_by, locator, value=None):
    """Select an element identified by the provided locator"""
    web_utils = context.web_utils
    if 'css' in locator_by:
        selector = locator\
            .replace("\"", "'").\
            replace("\'", "'")\
            .replace("\\'", "'")
        elem = web_utils.find_element_by_css_selector(selector, wait=2, retries=30)
    else:
        elem = web_utils.find_element(locator_by, locator, wait=2, retries=30)
    if not elem.is_selected():
        click_on_element(elem)
    if value:
        value_elem = Select(elem)
        try:
            value_locator_by, value_locator = value.split('=', 1) if '=' in value else ('', value)
            if value_locator_by == 'value':
                value_elem.select_by_value(value_locator)
            elif value_locator_by == 'index':
                value_elem.select_by_index(value_locator)
            else:
                value_elem.select_by_visible_text(value_locator)
        except Exception:
            print('Could not locate element: {}'.format(value))



@step(u'I deselect element with {locator_by} "{locator}"')
def deselect_path(context, locator_by, locator):
    """Deselect an element identified by the provided locator"""
    web_utils = context.web_utils
    if 'css' in locator_by:
        selector = locator\
            .replace("\"", "'")\
            .replace("\'", "'")\
            .replace("\\'", "'")
        elem = web_utils.find_element_by_css_selector(selector, wait=2, retries=30)
    else:
        elem = web_utils.find_element(locator_by, locator, wait=2, retries=30)
    if elem.is_selected():
        click_on_element(elem)


@step(u'I submit element with {locator_by} "{locator}"')
def submit_element(context, locator_by, locator):
    """Submit a form using the identified by the provided locator"""
    web_utils = context.web_utils
    elem = web_utils.find_element(locator_by, locator, wait=2, retries=30)
    elem.submit()


@step(u'I close element with {locator_by} "{locator}"')
def find_element_by_perfoming_close(context, locator_by, locator):
    """Close an element identified by the provided locator"""
    web_utils = context.web_utils
    elem = web_utils.find_element(locator_by, locator, wait=2, retries=30)
    elem.close()


@step(u'I double click on element with {locator_by} "{locator}"')
def double_click_element(context, locator_by, locator):
    """Double click on an element identified by the provided locator"""
    web_utils = context.web_utils
    elem = web_utils.find_element(locator_by, locator, wait=2, retries=30)
    click_on_element(elem)
    click_on_element(elem)


@step(u'I mouse over on element with {locator_by} "{locator}"')
def mouse_over_on_element(context, locator_by, locator):
    """Mouse over on an element identified by the provided locator"""
    web_utils = context.web_utils
    elem = web_utils.find_element(locator_by, locator, wait=2, retries=30)
    action = ActionChains(web_utils.driver)
    action.move_to_element(elem).perform()


@step(u'I drag element with {locator_by} "{locator}" into element with {'
      u'locator2_by} "{locator2}"')
def drag_to_and_drop_element(
        context, locator_by, locator, locator2_by, locator2):
    """Drag to and drop an element"""
    web_utils = context.web_utils
    elem = web_utils.find_element(locator_by, locator, wait=2, retries=30)
    elem2 = web_utils.find_element(locator2_by, locator2, wait=2, retries=30)
    action = ActionChains(web_utils.driver)
    action.drag_and_drop(elem, elem2).perform()


@step(u'I click and hold on element with {locator_by} "{locator}"')
def click_and_holder_element(context, locator_by, locator):
    """Click and hold on an element identified by the provided locator"""
    web_utils = context.web_utils
    elem = web_utils.find_element(locator_by, locator, wait=2, retries=30)
    action = ActionChains(web_utils.driver)
    action.click_and_hold(elem).perform()


@step(u'I release the element with {locator_by} "{locator}"')
def release_element(context, locator_by, locator):
    """Release an element identified by the provided locator"""
    web_utils = context.web_utils
    elem = web_utils.find_element(locator_by, locator, wait=2, retries=30)
    action = ActionChains(web_utils.driver)
    action.release(elem).perform()


@step(u'I save a screenshot as "{file_name}"')
def save_screenshot(context, file_name):
    """Save a screenshot of the current page to the specified filename"""
    context.web_utils.driver.get_screenshot_as_file(file_name)


@step(u'I switch to frame "{identifier}"')
def switch_to_frame(context, identifier):
    """Switch to a specific frame"""
    context.web_utils.driver.switch_to_frame(identifier)


@step(u'I switch to frame by index "{index}"')
def switch_to_frame_by_index(context, index):
    """Switch to a frame identified by it's index"""
    context.web_utils.driver.switch_to_frame(int(index))


@step(u'I switch to window "{name}"')
def switch_to_windows(context, name):
    """Switch to a specified window"""
    context.web_utils.driver.switch_to_window(name)


@step(u'I switch to default content')
def switch_to_default_content(context):
    """Switch to default content"""
    context.web_utils.driver.switch_to_default_content()


@step(u'I insert text "{text}" into the alert')
def insert_text_into_alert(context, text):
    """Insert the specified text into the displayed alert window"""
    alert = context.web_utils.driver.switch_to_alert()
    assert alert, u'Alert not found'
    alert.send_keys(text)
